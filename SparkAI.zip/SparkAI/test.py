import speech_recognition
from playsound import playsound
from gtts import gTTS


def GetAudio():
    r = speech_recognition.Recognizer()
    with speech_recognition.Microphone() as source:
        audio = r.listen(source)
        said = ''

        try: 
            said = r.recognize_google(audio)
            
        except Exception as e:
            print(e)

    return

def PlayAudio(audio):
    tts = gTTS(text=audio, Lang='en')
    tts.save('playFile.mp3')
    playsound('playFile.mp3')


while True:
    PlayAudio(GetAudio())
