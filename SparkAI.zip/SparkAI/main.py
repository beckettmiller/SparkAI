from wit import Wit
import speech_recognition as sr

import inquirer
from colorama import Fore
import os
import random
from playsound import playsound
from pydub import AudioSegment

import pyaudio

class Inquire:
    def Question(question, options):
        questions = [
        inquirer.List('decision',
                        message=question,
                        choices=options,
                    ),
            ]
        return inquirer.prompt(questions).get('decision')



class Help:
    def main():
        print(Fore.GREEN + ''' 
         ______                                 __       
        /      \                               /  |      
        /$$$$$$  |  ______    ______    ______  $$ |   __ 
        $$ \__$$/  /      \  /      \  /      \ $$ |  /  |
        $$      \ /$$$$$$  | $$$$$$  |/$$$$$$  |$$ |_/$$/ 
        $$$$$$  |$$ |  $$ | /    $$ |$$ |  $$/ $$   $$<  
        /  \__$$ |$$ |__$$ |/$$$$$$$ |$$ |      $$$$$$  \ 
        $$    $$/ $$    $$/ $$    $$ |$$ |      $$ | $$  |
        $$$$$$/  $$$$$$$/   $$$$$$$/ $$/       $$/   $$/ 
                $$ |                                    
                $$ |                                    
                $$/       
                ''')
        print(Fore.CYAN + 'Meet Spark, the intelligent grandma who helps fight online fraud!')
        print(Fore.YELLOW + 'Here is how you can use her! \n \n')

        print(Fore.MAGENTA + 'Call:' + Fore.RED + ' Choosing "Call" turns on Spark. She will listen for incoming audio')
        print(Fore.MAGENTA + 'Inspect:' + Fore.RED + ' Choosing "Inspect Transcript" allows one to read the transcripts of the calls')
        print(Fore.WHITE)


class TextFiles:
    
    def write(File, Message):
        with open(File, 'r+') as TextFile:
            TextFile.write(Message)

    def empty(File):
        with open(File, 'r+') as TextFile:
            TextFile.truncate(0)

    def checksize(self, File):
        if os.path.getsize(File) == 0:
            return True
        
        else:
            return False

    def getText(self, File):
        with open(File, 'r+') as TextFile:
            for line in TextFile:
                print(Fore.MAGENTA + line + '\n\n')

    def generateList(self):
        transcripts = []
        for i in range(1, 11):
            transcripts.append('call' + str(i) + '.txt')

        return transcripts

    def find_empty(self):
        file_list = self.generateList()

        for file in file_list:
            if self.checksize(file):
                return file
                break
                empty = True
            
            else:
                empty = False

        if empty == False:
            print(Fore.RED + '[WARNING]: No files are empty. Emptying file(s): ' + Fore.GREEN + 'call10.txt' + Fore.WHITE)
        
            self.empty('call10.txt')
            file = 'call10.txt'
        
        return file


    def inspect(self):
        transcripts = self.generateList()
        transcripts.append('Back')
        
        questions = [
            inquirer.List('decision',
                            message="What would you like to do?",
                            choices=transcripts,
                        ),
            ]
        answers = inquirer.prompt(questions).get('decision')

        if answers == 'Back':
            return
        else:
            if self.checksize(answers):
                print(Fore.RED + 'The following file(s): ' + Fore.BLUE + answers + Fore.RED + ' is empty \n\n')
            else:
                self.getText(answers)


class AI:
    def __init__(self):
        self.client = Wit('JGX7BV3KFHRFJKBM5OUVHOOU4MGLK5GV')
    def convert(list): 
        return (list[0].split()) 

    def getAudio(self):
        devices = []
        deviceIndex = []
        p = pyaudio.PyAudio()
        for i in range(p.get_device_count()):
            info = p.get_device_info_by_index(i)
            devices.append(str(info['index']) + ' ' + info['name'])
            deviceIndex.append(info['index'])
        
        data = Inquire.Question('Which audio device do you want to use?', devices)
        print(int(deviceIndex[devices.index(data)]))
        return int(deviceIndex[devices.index(data)])

            

    def audio(self, source):
        print(Fore.GREEN + 'Listening for input' + Fore.WHITE)
        r = sr.Recognizer()
        with sr.Microphone(source) as source:
            audio = r.adjust_for_ambient_noise(source, duration=0.75)
            audio = r.listen(source, phrase_time_limit=5)
            said = ''

            try:
                said = r.recognize_google(audio)
                print(Fore.GREEN + 'Heard: ' + Fore.BLUE + said + Fore.WHITE)
            except Exception as e:
                print(e)


        return said


    def get_type(self, audio):
        try:
            data = self.client.message(audio).get('entities')
        except:
            try:
                data = self.client.message(audio).get('entities')
            except:
                print(Fore.RED + "There was an error on Wit.ai's side" + Fore.WHITE)
                return 'WIT Error'


        
        for entity in list(data):
            if entity != 'sentiment':
                return entity + '.' + data[entity][0].get('value')
        
        return 'None.true'



class FindAudio:
    def __init__(self):
        self.get_name = ['Audio/get_name/1.mp3', 'Audio/get_name/2.mp3']
        self.get_nameCalls = [0, 0]

        self.CantHear = ['Audio/CantHear/1.mp3', 'Audio/CantHear/1.mp3', 'Audio/CantHear/2.mp3']
        self.CantHearCalls = [0, 0, 0]

        self.get_buttons = ['Audio/get_buttons/1.mp3', 'Audio/get_buttons/2.mp3', 'Audio/get_buttons/3.mp3', 'Audio/get_buttons/4.mp3', 'Audio/get_buttons/5.mp3']
        self.get_buttonsCalls = [0, 0, 0, 0, 0]


        self.get_error = ['Audio/get_error/1.mp3', 'Audio/get_error/2.mp3', 'Audio/get_error/3.mp3', 'Audio/get_error/4.mp3', 'Audio/get_error/5.mp3']
        self.get_errorCalls = [0, 0, 0, 0, 0]

        self.greeting = ['Audio/Greeting/1.mp3', 'Audio/Greeting/2.mp3', 'Audio/Greeting/3.mp3']
        self.greetingCalls = [0, 0, 0]

        self.scare = ['Audio/scare/1.mp3']
        self.scareCalls = [0]

        self.get_computer = ['Audio/get_computer/1.mp3', 'Audio/get_computer/2.mp3', 'Audio/get_computer/3.mp3']
        self.get_computer = [0, 0, 0]

    

    def get_transcript(self, file):
        pass

    
    def playAudio(self, type, file, lastFile):
        if type == 'intent.get_buttons':
            file = random.choice(self.get_buttons)
            playsound(file)
        
        elif type == 'intent.get_name':
            file = random.choice(self.get_name)
            playsound(file)
            
        if type == 'intent.get_repeat':
            if lastFile != None:
                playsound(lastFile)
        
        elif type == 'intent.get_error':
            file = random.choice(self.get_error)
            playsound(file)
        
        elif type == 'greetings.true':
            file = random.choice(self.greeting)
            playsound(file)
        
        elif type == 'intent.scare':
            file = random.choice(self.scare)
            playsound(file)

        elif type == 'intent.get_date' or type == 'intent.get_device' or type == 'intent.near_computer':
            file = random.choice(self.get_computer)
            playsound(file)
        
        else:
            file = random.choice(self.CantHear)
            playsound(file)

        
        return str(file)



class Main():
    def main():
        options = ['Call', 'Review Transcripts', 'Help', Fore.RED + 'Exit' + Fore.WHITE]
        answer = Inquire.Question(Fore.CYAN + 'Welcome to Spark AI' + Fore.WHITE, options)

        if answer == 'Call':
            for i in range(0, 20):
                print(' ')


            Artifical = AI()
            print(Fore.BLUE + 'Use Google to Terminal' + Fore.WHITE)
            version = Artifical.getAudio()
            txt = TextFiles()
            file = txt.find_empty()
            lastFile = None
            while True:
                y = Artifical.get_type(Artifical.audio(version))
                print(y)
                lastFile = FindAudio().playAudio(y, file, lastFile)
                print(Fore.WHITE)
        elif answer == 'Help':
            for i in range(0, 50):
                print(' ')
            Help.main()

        elif answer == 'Review Transcripts':
            for i in range(0, 20):
                print(' ')
            TextFiles().inspect()

        else:
            for i in range(0,100):
                print(' ')
            print(Fore.BLUE + 'Thanks for using Spark :D' + Fore.WHITE)
            exit()


        
for i in range(0, 150):
    print(' ')
    
print(Fore.RED + ''' 
     ______                                 __       
    /      \                               /  |      
    /$$$$$$  |  ______    ______    ______  $$ |   __ 
    $$ \__$$/  /      \  /      \  /      \ $$ |  /  |
    $$      \ /$$$$$$  | $$$$$$  |/$$$$$$  |$$ |_/$$/ 
    $$$$$$  |$$ |  $$ | /    $$ |$$ |  $$/ $$   $$<  
    /  \__$$ |$$ |__$$ |/$$$$$$$ |$$ |      $$$$$$  \ 
    $$    $$/ $$    $$/ $$    $$ |$$ |      $$ | $$  |
    $$$$$$/  $$$$$$$/   $$$$$$$/ $$/       $$/   $$/ 
            $$ |                                    
            $$ |                                    
            $$/       
            ''')
        
print(Fore.WHITE + '')

while True:
    Main.main()